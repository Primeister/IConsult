﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IConsult
{
    internal class StudentClass
    {
        public static List<string> fName = new List<string>();
        public static List<string> lName = new List<string>();
        public static List<string> studNo = new List<string>();
        public static List<string> degType = new List<string>();
        public static List<string> password = new List<string>();
    }
}
